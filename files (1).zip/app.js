/**
 * Bappu.ai - Complete ChatGPT-style AI Assignment & Accounting Helper
 * Single Page Application logic with Netlify function support & Gemini REST fallback.
 */

// --- Default Configuration & Accounting Knowledge Base ---
const DEFAULT_ACCOUNTING_TOPICS = [
  {
    id: 'fin-acc-1',
    subject: 'Financial Accounting',
    titleEn: 'Double-Entry Bookkeeping & Golden Rules',
    titleBn: 'দুতরফা দাখিলা পদ্ধতি ও সুবর্ণ নিয়মাবলী',
    prompt: 'Explain the Golden Rules of Accounting (Traditional vs Modern approach) with journal entry examples for a merchandising business. Provide ledger postings and a trial balance format.'
  },
  {
    id: 'cost-acc-1',
    subject: 'Cost Accounting',
    titleEn: 'Preparation of Cost Sheet & CVP Analysis',
    titleBn: 'উৎপাদন ব্যয় বিবরণী ও ব্রেক-ইভেন বিশ্লেষণ',
    prompt: 'Prepare a comprehensive Cost Sheet format including Prime Cost, Factory Cost, Cost of Production, and Cost of Goods Sold. Follow with Break-Even Point (BEP) formulas in units and currency.'
  },
  {
    id: 'adv-acc-1',
    subject: 'Advanced Accounting',
    titleEn: 'Partnership Dissolution & Piecemeal Distribution',
    titleBn: 'অংশীদারি কারবার বিলোপসাধন ও ক্রমিক বন্টন',
    prompt: 'Explain the Garner vs Murray rule upon insolvency of a partner in accounting, and provide step-by-step piecemeal distribution calculation.'
  },
  {
    id: 'tax-1',
    subject: 'Taxation & Auditing',
    titleEn: 'Corporate Tax Computation & Audit Standards',
    titleBn: 'কর নির্ধারণ ও নিরীক্ষা মানদণ্ড',
    prompt: 'Detail the procedure of calculating taxable business income from audited financial statements, highlighting allowable vs disallowable expenses according to Income Tax guidelines.'
  },
  {
    id: 'mgmt-acc-1',
    subject: 'Management Accounting',
    titleEn: 'Variance Analysis & Standard Costing',
    titleBn: 'বিচ্যুতি বিশ্লেষণ ও প্রমিত ব্যয় নির্ধারণ',
    prompt: 'Calculate Material Cost Variance, Material Price Variance, and Material Usage Variance given standard vs actual data. Present results in a clear accounting table.'
  }
];

const INITIAL_ADMIN_HASH = '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'; // SHA-256 for 'admin' fallback or 507242 check

// --- State Management ---
const state = {
  activeTab: 'chat', // 'chat' | 'library' | 'studio' | 'admin' | 'settings'
  splitPreview: false,
  sessions: [],
  currentSessionId: null,
  isGenerating: false,
  adminLoggedIn: false,
  adminPasswordHash: localStorage.getItem('bappu_admin_pwd_hash') || null, // default check handles 507242
  config: {
    apiKey: localStorage.getItem('bappu_gemini_api_key') || '',
    model: localStorage.getItem('bappu_gemini_model') || 'gemini-2.5-flash',
    systemPrompt: localStorage.getItem('bappu_system_prompt') || 'You are Bappu.ai, a distinguished professor and expert academic assignment assistant specializing in BBA Honours Accounting, National University curriculum, and business studies. Provide well-structured, clear answers with formal headings, tables, step-by-step calculations, journal entries, and Bengali or English explanations according to the user preference.',
    language: 'both', // 'bn', 'en', 'both'
    subject: 'General Accounting',
    studentName: localStorage.getItem('bappu_student_name') || 'Md. Sujar Biswas (Bappu)',
    studentId: localStorage.getItem('bappu_student_id') || 'Roll: 212500, Reg: 1922501',
    institution: localStorage.getItem('bappu_institution') || 'Govt. Shaheed Bulbul College, Pabna (National University)',
    department: 'Department of Accounting',
    courseTitle: 'Principles of Accounting'
  },
  studioDoc: {
    title: 'Comprehensive Accounting Assignment',
    subtitle: 'Submitted for Partial Fulfillment of BBA (Honours)',
    content: '# Principles of Accounting\n\n## 1. Introduction to Double-Entry System\nIn modern financial accounting, every financial transaction impacts at least two accounts following the equation:\n\n$$\\text{Assets} = \\text{Liabilities} + \\text{Owner\'s Equity}$$\n\n### Golden Rules Summary Table\n| Account Type | Debit Effect | Credit Effect |\n| :--- | :--- | :--- |\n| **Assets** | Increase (+) | Decrease (-) |\n| **Liabilities** | Decrease (-) | Increase (+) |\n| **Equity/Capital** | Decrease (-) | Increase (+) |\n| **Revenue** | Decrease (-) | Increase (+) |\n| **Expenses** | Increase (+) | Decrease (-) |\n\n*Prepared using Bappu.ai Academic Studio.*'
  }
};

// --- Helper Functions ---
function getTimestamp() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// --- Session & Storage Management ---
function loadSessions() {
  const stored = localStorage.getItem('bappu_sessions');
  if (stored) {
    try {
      state.sessions = JSON.parse(stored);
    } catch (e) {
      state.sessions = [];
    }
  }
  if (!state.sessions || state.sessions.length === 0) {
    createNewSession('New Accounting Chat');
  } else {
    state.currentSessionId = state.sessions[0].id;
  }
}

function saveSessions() {
  localStorage.setItem('bappu_sessions', JSON.stringify(state.sessions));
}

function getCurrentSession() {
  return state.sessions.find(s => s.id === state.currentSessionId) || state.sessions[0];
}

function createNewSession(title = 'New Accounting Chat') {
  const id = 'sess_' + Date.now();
  const newSession = {
    id,
    title,
    createdAt: new Date().toISOString(),
    messages: [
      {
        id: 'msg_welcome',
        role: 'assistant',
        time: getTimestamp(),
        content: `**স্বাগতম Bappu.ai-তে!** 👋\n\nআমি আপনার BBA Honours Accounting ও ব্যবসায় শিক্ষা অ্যাসাইনমেন্ট হেল্পার।\n\n- হিসাববিজ্ঞান নীতিমালা, জাবেদা, খতিয়ান, রেওয়ামিল\n- উৎপাদন ব্যয় বিবরণী ও কস্ট অ্যাকাউন্টিং\n- অংশীদারি কারবার, আয়কর ও নিরীক্ষা\n- এবং সম্পূর্ণ ফরম্যাটেড পিডিএফ অ্যাসাইনমেন্ট তৈরির জন্য প্রস্তুত।\n\nনিচে আপনার প্রশ্ন লিখুন অথবা বাম পাশের **Accounting Library** থেকে যেকোনো টপিক বেছে নিন!`
      }
    ]
  };
  state.sessions.unshift(newSession);
  state.currentSessionId = id;
  saveSessions();
  renderSessionList();
  renderMessages();
}

function selectSession(id) {
  state.currentSessionId = id;
  renderSessionList();
  renderMessages();
}

function deleteSession(id, event) {
  if (event) event.stopPropagation();
  state.sessions = state.sessions.filter(s => s.id !== id);
  if (state.sessions.length === 0) {
    createNewSession();
  } else {
    state.currentSessionId = state.sessions[0].id;
  }
  saveSessions();
  renderSessionList();
  renderMessages();
}

// --- Markdown Rendering ---
function renderMarkdown(md) {
  if (typeof marked !== 'undefined') {
    return marked.parse(md, { breaks: true, gfm: true });
  }
  // Simple fallback if CDN hasn't loaded yet
  return md.replace(/\n/g, '<br/>');
}

// --- UI Rendering Functions ---
function renderSessionList() {
  const listEl = document.getElementById('session-list');
  if (!listEl) return;
  listEl.innerHTML = '';

  state.sessions.forEach(sess => {
    const isSelected = sess.id === state.currentSessionId;
    const item = document.createElement('div');
    item.className = `flex items-center justify-between p-2.5 rounded-lg cursor-pointer text-sm transition-colors ${
      isSelected ? 'bg-blue-900/40 text-blue-300 font-medium border border-blue-700/50' : 'text-slate-300 hover:bg-slate-800'
    }`;
    item.onclick = () => selectSession(sess.id);

    item.innerHTML = `
      <div class="flex items-center space-x-2 truncate pr-2">
        <svg class="w-4 h-4 flex-shrink-0 ${isSelected ? 'text-blue-400' : 'text-slate-500'}" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
        </svg>
        <span class="truncate">${escapeHtml(sess.title)}</span>
      </div>
      <button class="text-slate-500 hover:text-red-400 p-1 rounded" onclick="deleteSession('${sess.id}', event)" title="Delete Chat">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
      </button>
    `;
    listEl.appendChild(item);
  });
}

function renderMessages() {
  const container = document.getElementById('chat-messages');
  if (!container) return;
  const current = getCurrentSession();
  container.innerHTML = '';

  current.messages.forEach((msg, idx) => {
    const isUser = msg.role === 'user';
    const row = document.createElement('div');
    row.className = `flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`;

    const inner = document.createElement('div');
    inner.className = `flex max-w-[85%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start gap-3`;

    // Avatar
    const avatar = document.createElement('div');
    avatar.className = `w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${
      isUser ? 'bg-blue-600 text-white ml-2' : 'bg-slate-800 text-blue-400 border border-blue-500/30 mr-2'
    }`;
    avatar.textContent = isUser ? 'You' : 'B';

    // Bubble content
    const bubble = document.createElement('div');
    bubble.className = `p-4 rounded-2xl shadow-sm text-sm ${
      isUser 
        ? 'bg-blue-600 text-white rounded-tr-none' 
        : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-tl-none chat-prose'
    }`;

    if (isUser) {
      bubble.textContent = msg.content;
    } else {
      bubble.innerHTML = renderMarkdown(msg.content);
      
      // Actions row for assistant messages
      const actions = document.createElement('div');
      actions.className = 'flex items-center gap-2 mt-3 pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs text-slate-400';
      actions.innerHTML = `
        <button onclick="copyMessage(${idx})" class="hover:text-blue-500 flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700/50">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
          Copy
        </button>
        <button onclick="sendToStudio(${idx})" class="hover:text-amber-500 flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700/50">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
          Open in PDF Studio
        </button>
        <button onclick="regenerateLast()" class="hover:text-green-500 flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700/50">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
          Regenerate
        </button>
        <span class="ml-auto text-[11px] opacity-60">${msg.time || ''}</span>
      `;
      bubble.appendChild(actions);
    }

    inner.appendChild(avatar);
    inner.appendChild(bubble);
    row.appendChild(inner);
    container.appendChild(row);
  });

  // Scroll to bottom
  container.scrollTop = container.scrollHeight;
}

function escapeHtml(text) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return (text || '').replace(/[&<>"']/g, m => map[m]);
}

// --- Action Handlers ---
function copyMessage(idx) {
  const current = getCurrentSession();
  const msg = current.messages[idx];
  if (msg) {
    navigator.clipboard.writeText(msg.content);
    showToast('Copied to clipboard!');
  }
}

function sendToStudio(idx) {
  const current = getCurrentSession();
  const msg = current.messages[idx];
  if (msg) {
    state.studioDoc.title = current.title || 'Accounting Assignment';
    state.studioDoc.content = msg.content;
    switchTab('studio');
    updateStudioPreview();
    showToast('Loaded into PDF Studio!');
  }
}

function regenerateLast() {
  const current = getCurrentSession();
  if (current.messages.length === 0) return;
  // find last user message
  for (let i = current.messages.length - 1; i >= 0; i--) {
    if (current.messages[i].role === 'user') {
      const q = current.messages[i].content;
      // remove subsequent assistant response if exists
      current.messages = current.messages.slice(0, i + 1);
      saveSessions();
      renderMessages();
      executeGeminiQuery(q);
      break;
    }
  }
}

// --- Gemini API Invocation (Serverless with Direct REST Fallback) ---
async function executeGeminiQuery(userPrompt) {
  if (state.isGenerating) return;
  state.isGenerating = true;
  updateLoadingStatus(true, 'Consulting Gemini AI & Accounting Knowledge Base...');

  const current = getCurrentSession();
  const subject = state.config.subject;
  const lang = state.config.language;
  const model = state.config.model;

  // Build conversational context
  const contents = [];
  const systemInstruction = `${state.config.systemPrompt}\nCurrent Subject: ${subject}. Preferred Language: ${lang}. Format all financial statements with standard columns and include step-by-step accounting explanations.`;

  // Include recent turns for multi-turn history.
  // Skip error bubbles and leading assistant messages (Gemini expects the history to start with a user turn).
  let recentTurns = current.messages
    .filter(m => !String(m.id || '').startsWith('msg_err_'))
    .slice(-6);
  while (recentTurns.length && recentTurns[0].role !== 'user') {
    recentTurns = recentTurns.slice(1);
  }
  recentTurns.forEach(m => {
    contents.push({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    });
  });

  let assistantResponse = '';

  try {
    // Attempt 1: Call Netlify Serverless Function at /.netlify/functions/gemini
    let serverlessSuccess = false;
    try {
      const fnResponse = await fetch('/.netlify/functions/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents,
          systemInstruction,
          model: model || 'gemini-2.5-flash'
        })
      });

      if (fnResponse.ok) {
        const data = await fnResponse.json();
        if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
          assistantResponse = data.candidates[0].content.parts[0].text;
          serverlessSuccess = true;
        } else if (data.text) {
          assistantResponse = data.text;
          serverlessSuccess = true;
        }
      }
    } catch (e) {
      console.log('Netlify function not reached or errored, trying client key fallback...', e);
    }

    // Attempt 2: If serverless function did not produce a response, use Client API Key directly
    if (!serverlessSuccess) {
      const apiKey = state.config.apiKey.trim();
      if (!apiKey) {
        throw new Error(
          'Gemini API Key is required! Either configure GEMINI_API_KEY in your Netlify site environment variables, or enter your API key in the Bappu.ai Settings menu (⚙️).'
        );
      }

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
      
      const payload = {
        systemInstruction: {
          parts: [{ text: systemInstruction }]
        },
        contents: contents,
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 4096
        }
      };

      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        const errMessage = errJson.error?.message || `HTTP ${res.status} ${res.statusText}`;
        if (res.status === 400 && errMessage.includes('API_KEY_INVALID')) {
          throw new Error('Your Gemini API key appears invalid or expired. Please check Settings.');
        } else if (res.status === 429) {
          throw new Error('Gemini API rate limit or quota exceeded. Please wait a minute or use a different key.');
        } else {
          throw new Error(`Gemini API Error: ${errMessage}`);
        }
      }

      const data = await res.json();
      assistantResponse = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!assistantResponse) {
        throw new Error('Received empty response from Gemini. Please rephrase or try again.');
      }
    }

    // Append response
    current.messages.push({
      id: 'msg_' + Date.now(),
      role: 'assistant',
      time: getTimestamp(),
      content: assistantResponse
    });

  } catch (err) {
    current.messages.push({
      id: 'msg_err_' + Date.now(),
      role: 'assistant',
      time: getTimestamp(),
      content: `⚠️ **Generation Failed**\n\n${err.message}\n\n*Tip: Click the Settings button (⚙️) on the top right to configure your API key, or visit Netlify Site Configuration to add ` + "`GEMINI_API_KEY`."
    });
  } finally {
    state.isGenerating = false;
    updateLoadingStatus(false);
    saveSessions();
    renderMessages();
  }
}

function updateLoadingStatus(loading, text = '') {
  const ind = document.getElementById('loading-indicator');
  const btn = document.getElementById('send-btn');
  const input = document.getElementById('chat-input');
  if (ind) {
    ind.classList.toggle('hidden', !loading);
    const label = document.getElementById('loading-text');
    if (label) label.textContent = text;
  }
  if (btn) btn.disabled = loading;
  if (input) input.disabled = loading;
}

// --- Submit User Message ---
function submitMessage() {
  const input = document.getElementById('chat-input');
  if (!input) return;
  const text = input.value.trim();
  if (!text || state.isGenerating) return;

  const current = getCurrentSession();
  current.messages.push({
    id: 'msg_' + Date.now(),
    role: 'user',
    time: getTimestamp(),
    content: text
  });

  if (current.messages.filter(m => m.role === 'user').length === 1) {
    current.title = text.slice(0, 32) + (text.length > 32 ? '...' : '');
    renderSessionList();
  }

  input.value = '';
  input.style.height = 'auto';
  saveSessions();
  renderMessages();
  executeGeminiQuery(text);
}

// --- Tab Switching ---
function switchTab(tab) {
  state.activeTab = tab;
  ['chat', 'library', 'studio', 'admin', 'settings'].forEach(t => {
    const pane = document.getElementById(`pane-${t}`);
    const nav = document.getElementById(`nav-${t}`);
    if (pane) pane.classList.toggle('hidden', t !== tab);
    if (nav) {
      if (t === tab) {
        nav.classList.add('bg-blue-600', 'text-white');
        nav.classList.remove('text-slate-400', 'hover:bg-slate-800');
      } else {
        nav.classList.remove('bg-blue-600', 'text-white');
        nav.classList.add('text-slate-400', 'hover:bg-slate-800');
      }
    }
  });

  if (tab === 'studio') {
    updateStudioPreview();
  } else if (tab === 'library') {
    renderLibrary();
  }
}

// --- Accounting Library Render ---
function renderLibrary() {
  const container = document.getElementById('library-cards');
  if (!container) return;
  container.innerHTML = '';

  DEFAULT_ACCOUNTING_TOPICS.forEach(topic => {
    const card = document.createElement('div');
    card.className = 'bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-blue-500 transition-all';
    card.innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <span class="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300">${topic.subject}</span>
      </div>
      <h3 class="font-bold text-slate-800 dark:text-slate-100 text-base mb-1">${topic.titleEn}</h3>
      <p class="text-xs text-slate-500 dark:text-slate-400 mb-3">${topic.titleBn}</p>
      <p class="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded border border-slate-100 dark:border-slate-700/60 mb-4 line-clamp-2">${topic.prompt}</p>
      <button onclick="askLibraryPrompt('${topic.id}')" class="w-full py-2 px-3 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center justify-center gap-1.5 transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
        Generate Assignment with Gemini
      </button>
    `;
    container.appendChild(card);
  });
}

function askLibraryPrompt(id) {
  const topic = DEFAULT_ACCOUNTING_TOPICS.find(t => t.id === id);
  if (!topic) return;
  switchTab('chat');
  createNewSession(topic.titleEn);
  const input = document.getElementById('chat-input');
  if (input) input.value = topic.prompt;
  submitMessage();
}

// --- PDF Studio & Document Customizer ---
function updateStudioPreview() {
  const preview = document.getElementById('pdf-preview-box');
  const titleInput = document.getElementById('studio-title');
  const contentInput = document.getElementById('studio-content');
  if (titleInput && !titleInput.value) titleInput.value = state.studioDoc.title;
  if (contentInput && !contentInput.value) contentInput.value = state.studioDoc.content;

  const currentTitle = titleInput ? titleInput.value : state.studioDoc.title;
  const currentContent = contentInput ? contentInput.value : state.studioDoc.content;

  if (preview) {
    preview.innerHTML = `
      <div id="pdf-render-area" class="bg-white text-slate-900 p-8 md:p-12 shadow-md rounded-lg max-w-3xl mx-auto border border-slate-200">
        <!-- Cover Header -->
        <div class="text-center pb-8 border-b-2 border-slate-800 mb-8">
          <p class="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-1">${escapeHtml(state.config.institution)}</p>
          <p class="text-sm font-semibold text-blue-900 mb-4">${escapeHtml(state.config.department)}</p>
          <h1 class="text-2xl font-bold text-slate-900 uppercase tracking-tight mb-2">${escapeHtml(currentTitle)}</h1>
          <p class="text-sm italic text-slate-600">${escapeHtml(state.config.courseTitle)}</p>
        </div>

        <!-- Student Meta -->
        <div class="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200 mb-8">
          <div>
            <p class="font-bold text-slate-700">SUBMITTED BY:</p>
            <p class="font-semibold text-slate-900">${escapeHtml(state.config.studentName)}</p>
            <p class="text-slate-600">${escapeHtml(state.config.studentId)}</p>
          </div>
          <div class="text-right">
            <p class="font-bold text-slate-700">SUBMITTED TO:</p>
            <p class="font-semibold text-slate-900">Course Instructor</p>
            <p class="text-slate-600">Date: ${new Date().toLocaleDateString('en-GB')}</p>
          </div>
        </div>

        <!-- Document Body -->
        <div class="chat-prose text-slate-800">
          ${renderMarkdown(currentContent)}
        </div>

        <div class="mt-12 pt-4 border-t border-slate-200 flex justify-between text-[11px] text-slate-400">
          <span>Bappu.ai Academic Assignment Engine</span>
          <span>Page 1 of 1</span>
        </div>
      </div>
    `;
  }
}

function downloadPdf() {
  window.print();
}

// --- Admin Panel Authentication & Management ---
async function handleAdminLogin() {
  const pwdInput = document.getElementById('admin-password');
  const errorEl = document.getElementById('admin-error');
  if (!pwdInput) return;
  const pass = pwdInput.value.trim();
  errorEl.textContent = '';

  // Compare only against the stored hash, or the initial default hash if no password was set yet.
  // (Previously a plaintext '507242' check bypassed the changed password.)
  const hash = await sha256(pass);
  const targetHash = state.adminPasswordHash || await sha256('507242');

  if (hash === targetHash) {
    state.adminLoggedIn = true;
    renderAdminPanel();
    showToast('Admin access granted!');
  } else {
    errorEl.textContent = 'Incorrect password. (Initial admin password is 507242)';
  }
}

function renderAdminPanel() {
  const loginCard = document.getElementById('admin-login-card');
  const dashCard = document.getElementById('admin-dashboard');
  if (loginCard) loginCard.classList.toggle('hidden', state.adminLoggedIn);
  if (dashCard) dashCard.classList.toggle('hidden', !state.adminLoggedIn);

  if (state.adminLoggedIn) {
    document.getElementById('admin-system-prompt').value = state.config.systemPrompt;
    document.getElementById('admin-model-select').value = state.config.model;
  }
}

async function updateAdminPassword() {
  const newPass = document.getElementById('admin-new-password').value.trim();
  if (newPass.length < 6) {
    showToast('Password must be at least 6 characters');
    return;
  }
  const newHash = await sha256(newPass);
  state.adminPasswordHash = newHash;
  localStorage.setItem('bappu_admin_pwd_hash', newHash);
  showToast('Admin password updated successfully!');
  document.getElementById('admin-new-password').value = '';
}

function saveAdminSettings() {
  const prompt = document.getElementById('admin-system-prompt').value.trim();
  const model = document.getElementById('admin-model-select').value;
  state.config.systemPrompt = prompt;
  state.config.model = model;
  localStorage.setItem('bappu_system_prompt', prompt);
  localStorage.setItem('bappu_gemini_model', model);
  showToast('Settings saved to database!');
}

function adminLogout() {
  state.adminLoggedIn = false;
  renderAdminPanel();
  showToast('Logged out of Admin');
}

// --- User Settings Modal / Tab ---
function saveUserSettings() {
  const key = document.getElementById('setting-api-key').value.trim();
  const name = document.getElementById('setting-student-name').value.trim();
  const id = document.getElementById('setting-student-id').value.trim();
  const inst = document.getElementById('setting-institution').value.trim();

  state.config.apiKey = key;
  state.config.studentName = name || state.config.studentName;
  state.config.studentId = id || state.config.studentId;
  state.config.institution = inst || state.config.institution;

  localStorage.setItem('bappu_gemini_api_key', key);
  localStorage.setItem('bappu_student_name', state.config.studentName);
  localStorage.setItem('bappu_student_id', state.config.studentId);
  localStorage.setItem('bappu_institution', state.config.institution);

  showToast('Settings saved successfully!');
  switchTab('chat');
}

// --- Toast Notification Helper ---
function showToast(msg) {
  let toast = document.getElementById('toast-notification');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast-notification';
    toast.className = 'fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-medium border border-slate-700 transition-opacity duration-300';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  setTimeout(() => { toast.style.opacity = '0'; }, 2800);
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
  loadSessions();
  renderSessionList();
  renderMessages();

  // Handle URL hash routing (e.g. #admin, #studio, #library)
  const hash = window.location.hash.replace('#', '');
  if (['admin', 'studio', 'library', 'settings'].includes(hash)) {
    switchTab(hash);
  }

  // Auto-resize chat textarea
  const input = document.getElementById('chat-input');
  if (input) {
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 180) + 'px';
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        submitMessage();
      }
    });
  }

  // Populate settings fields
  const keyInput = document.getElementById('setting-api-key');
  if (keyInput) keyInput.value = state.config.apiKey;
  const nameInput = document.getElementById('setting-student-name');
  if (nameInput) nameInput.value = state.config.studentName;
  const idInput = document.getElementById('setting-student-id');
  if (idInput) idInput.value = state.config.studentId;
  const instInput = document.getElementById('setting-institution');
  if (instInput) instInput.value = state.config.institution;
});
